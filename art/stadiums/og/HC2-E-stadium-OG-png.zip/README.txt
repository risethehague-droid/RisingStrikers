STADIUM - OG version (the final one): Het Kleine Loo as it really is
  Built from photos of the ground (staantribune.nl, In de Hekken drone shots, Haaglanden Voetbal, stadionautist).

  aseprite\HC2-E2-far-side.aseprite   far side (6429x900), layers back to front:
     backdrop + stand        sky, white flats, windmill, trees, pitch 2 + ball-stop fence + masts, kantine (striped
                             awning, VUC crest), penguin sign, plaza, walkway, and the main stand: green benches,
                             concrete stairs + yellow row plates, terracotta roof, VUC gables, glass end screens,
                             orange banners under the roof
     crowd (animated)        ~1150 fans on the benches in team sections + gulls on the ridge (booth area is a hole)
     commentary booth        green press box, white window frame, Rami 48px, ON AIR light
     front wall + players tunnel + masts
                             brick wall, white pillars, white/yellow boards, ERELEDEN plate, BESTUUR door, white roof
                             columns, the telescopic tunnel (black/white ribs), walkway floodlight masts
     pitch-side boards       sponsors + venue, open gate in front of the tunnel
     standing fans + railing + banners (animated)
                             ~250 people standing 2-3 deep at the white railing + on the plaza, full figures,
                             crest flags, signs, scarves; fan banners with the team crests tied to the railing;
                             the railing + yellow bins on top
  aseprite\HC2-E1-pitch.aseprite      pitch + ground outside + 'end railing fans + photographers + end boards'
                                      (animated) + near boards (draw over players)
  tags in both: crowd-idle (frames 1-4, 180ms) / crowd-cheer (frames 5-8, 140ms: arms up + jumping, flags faster)
  No LEDs, no flares, no stands behind the goals - like the real ground.  12 photographers (kneeling, FOTO bibs).

  Draw order in game: backdrop -> pitch -> ground -> crowd -> booth -> front wall + boards -> standing fans/railing/
  ends layer -> players -> near boards.  Players walk out of the tunnel mouth (between the front wall and the boards).
  mockups\  in-game screens + overview;  HC2-E-stadium-OG-png.zip = every layer as PNG.
To make this the active stadium again: python3 env/use_stadium.py og  (then the downstream script)
